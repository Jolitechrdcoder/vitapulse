// ===============================
    // NAV
    // ===============================
    const addBtn = document.getElementById("addBtn");
    addBtn.addEventListener("click", () => {
      window.location.href = "anadir.html";
    });

    // ===============================
    // SETTINGS SCREEN OPEN/CLOSE
    // ===============================
    const settingsBtn = document.getElementById("settingsBtn");
    const backSettings = document.getElementById("backSettings");
    const settingsScreen = document.getElementById("settingsScreen");

    function openSettings(){
      settingsScreen.classList.add("open");
      settingsScreen.setAttribute("aria-hidden", "false");
    }
    function closeSettings(){
      settingsScreen.classList.remove("open");
      settingsScreen.setAttribute("aria-hidden", "true");
    }

    settingsBtn.addEventListener("click", openSettings);
    backSettings.addEventListener("click", closeSettings);

    // ===============================
    // THEME (Light / Dark) + LocalStorage
    // ===============================
    const LS_THEME = "vitapulse_theme";
    const themeToggle = document.getElementById("themeToggle");
    const root = document.documentElement;

    function applyTheme(theme){
      root.setAttribute("data-theme", theme);
      localStorage.setItem(LS_THEME, theme);
      themeToggle.classList.toggle("on", theme === "dark");
    }

    const savedTheme = localStorage.getItem(LS_THEME) || "light";
    applyTheme(savedTheme);

    themeToggle.addEventListener("click", () => {
      const current = root.getAttribute("data-theme") || "light";
      applyTheme(current === "dark" ? "light" : "dark");
    });

    // ===============================
    // LANGUAGE (ES/EN) + LocalStorage
    // ===============================
    const LS_LANG = "vitapulse_lang";
    const langSelect = document.getElementById("langSelect");

    const i18n = {
      es: {
        settings_title: "Ajustes",
        preferences: "Preferencias",
        theme: "Tema",
        theme_sub: "Claro / Oscuro",
        language: "Idioma",
        language_sub: "Selecciona",
        settings_note: "Los cambios se guardan en el dispositivo (LocalStorage).",
        greeting_lines: ["Hi.User", "Lef s measure", "your heart", "rate"]
      },
      en: {
        settings_title: "Settings",
        preferences: "Preferences",
        theme: "Theme",
        theme_sub: "Light / Dark",
        language: "Language",
        language_sub: "Select",
        settings_note: "Changes are saved on this device (LocalStorage).",
        greeting_lines: ["Hi.User", "Let’s measure", "your heart", "rate"]
      }
    };

    function applyLang(lang){
      const dict = i18n[lang] || i18n.es;
      localStorage.setItem(LS_LANG, lang);

      document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        if(key === "greeting_lines"){
          el.innerHTML = dict.greeting_lines.map(line => `<div>${line}</div>`).join("");
          return;
        }
        if(dict[key] != null) el.textContent = dict[key];
      });

      langSelect.value = lang;
    }

    const savedLang = localStorage.getItem(LS_LANG) || "es";
    applyLang(savedLang);

    langSelect.addEventListener("change", (e) => {
      applyLang(e.target.value);
    });

    // ===============================
    // (Demo) Values
    // ===============================
    const bpmEl = document.getElementById("bpmVal");
    const msEl  = document.getElementById("msVal");
    // opcional: demo tap en corazón para probar
    document.querySelector(".heart")?.addEventListener("click", () => {
      const bpm = Number(bpmEl.textContent) || 95;
      const ms  = Number(msEl.textContent)  || 86;
      bpmEl.textContent = String(Math.max(40, Math.min(180, bpm + (Math.random() > .5 ? 1 : -1))));
      msEl.textContent  = String(Math.max(50, Math.min(140, ms  + (Math.random() > .5 ? 1 : -1))));
    });