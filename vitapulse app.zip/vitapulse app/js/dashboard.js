const bpmEl = document.getElementById("bpmValue");
const hrvEl = document.getElementById("hrvValue");
const nameEl = document.getElementById("userName");
const dotEl = document.getElementById("connDot");
const mockBtn = document.getElementById("mockBtn");

function readUser(){
  try{
    const u = JSON.parse(localStorage.getItem("vitapulse_user") || "null");
    if (u?.name) nameEl.textContent = u.name;
  }catch{}
}

function updateConnectionDot(){
  const connected = localStorage.getItem("vitapulse_ble_connected") === "1";
  if (!dotEl) return;
  dotEl.style.background = connected ? "#22c55e" : "#ef4444";
  dotEl.style.boxShadow = connected
    ? "0 0 0 4px rgba(34,197,94,.15)"
    : "0 0 0 4px rgba(239,68,68,.15)";
  dotEl.title = connected ? "Conectado" : "Desconectado";
}

function updateMetrics(){
  const bpm = localStorage.getItem("vitapulse_bpm");
  if (bpmEl) bpmEl.textContent = bpm ? bpm : "--";


  if (hrvEl) {
    const n = bpm ? Number(bpm) : 0;
    const hrv = bpm ? Math.max(30, Math.min(140, Math.round(120 - (n - 60) * 0.9))) : null;
    hrvEl.textContent = hrv ? String(hrv) : "--";
  }

  updateConnectionDot();
}

readUser();
setInterval(updateMetrics, 400);


const canvas = document.getElementById("ecgCanvas");
const ctx = canvas?.getContext("2d");
let t = 0;
let history = [];
const MAX_POINTS = 320;


const DATA_TIMEOUT_MS = 2500;

function resizeCanvas(){
  if (!canvas) return;
  const w = canvas.clientWidth * devicePixelRatio;
  const h = 180 * devicePixelRatio;
  canvas.width = Math.max(600, Math.floor(w));
  canvas.height = Math.floor(h);
}
window.addEventListener("resize", resizeCanvas);
resizeCanvas();

function hasRecentBleData(){
  const connected = localStorage.getItem("vitapulse_ble_connected") === "1";
  const ts = Number(localStorage.getItem("vitapulse_bpm_ts") || "0");
  const bpm = Number(localStorage.getItem("vitapulse_bpm") || "0");

  if (!connected) return false;
  if (!ts) return false;
  if (Date.now() - ts > DATA_TIMEOUT_MS) return false;
  if (!Number.isFinite(bpm) || bpm <= 0) return false;

  return true;
}

function ecgSample(bpm){

  const base = Math.sin(t * 0.04) * 0.15;
  const rate = bpm ? bpm / 60 : 1.2;
  const phase = (t * 0.02 * rate) % 1;

  const qrs = Math.exp(-Math.pow((phase - 0.12) / 0.03, 2)) * 1.2;
  const p   = Math.exp(-Math.pow((phase - 0.04) / 0.02, 2)) * 0.25;
  const tw  = Math.exp(-Math.pow((phase - 0.28) / 0.06, 2)) * 0.35;

  return base + p + qrs - tw * 0.2;
}

function pushPoint(val){
  history.push(val);
  if (history.length > MAX_POINTS) history.shift();
}

function drawLine(){
  if (!canvas || !ctx) return;

  ctx.clearRect(0,0,canvas.width,canvas.height);

  // fondo sutil
  ctx.globalAlpha = 1;
  ctx.fillStyle = "rgba(255,255,255,0.02)";
  ctx.fillRect(0,0,canvas.width,canvas.height);

  // línea
  ctx.lineWidth = 3 * devicePixelRatio;
  ctx.strokeStyle = "rgba(200,180,255,0.9)";
  ctx.beginPath();

  const mid = canvas.height * 0.55;
  const amp = canvas.height * 0.25;

  for (let i=0; i<history.length; i++){
    const x = (i / (history.length-1)) * canvas.width;
    const y = mid - history[i] * amp;
    if (i === 0) ctx.moveTo(x,y);
    else ctx.lineTo(x,y);
  }
  ctx.stroke();
}

function drawECG(){
  if (!canvas || !ctx) return;

 
  if (!hasRecentBleData()){
    
    if (history.length < MAX_POINTS) {
      while (history.length < MAX_POINTS) history.push(0);
    } else {
      pushPoint(0);
    }
    drawLine();
    t += 1;
    requestAnimationFrame(drawECG);
    return;
  }

 
  const bpm = Number(localStorage.getItem("vitapulse_bpm") || "80");
  const s = ecgSample(bpm);
  pushPoint(s);

  drawLine();
  t += 1;
  requestAnimationFrame(drawECG);
}
drawECG();


mockBtn?.addEventListener("click", () => {
  const bpm = 60 + Math.floor(Math.random() * 60);
  localStorage.setItem("vitapulse_bpm", String(bpm));
  localStorage.setItem("vitapulse_bpm_ts", String(Date.now()));
  localStorage.setItem("vitapulse_ble_connected", "1"); 
  updateMetrics();
});
