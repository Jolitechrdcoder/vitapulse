const LS_DEVICES = "vitapulse_devices";
    const LS_ACTIVE  = "vitapulse_active_device";

   
    const scanBtn = document.getElementById("scanBtn");
    const stopBtn = document.getElementById("stopBtn");
    const disconnectBtn = document.getElementById("disconnectBtn");
    const continueBtn = document.getElementById("continueBtn");
    const statusText = document.getElementById("statusText");

    const scanList = document.getElementById("scanList");
    const savedList = document.getElementById("savedList");

    let selectedSavedId = null;
    let selectedScanId = null;

   
    let leScan = null;
    const seen = new Map(); 

    
    const esc = (s) => String(s ?? "").replace(/[&<>"']/g, m => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
    }[m]));

    function setStatus(msg){ statusText.textContent = msg; }

    function loadDevices(){
      try{ return JSON.parse(localStorage.getItem(LS_DEVICES) || "[]"); }
      catch{ return []; }
    }
    function saveDevices(list){
      localStorage.setItem(LS_DEVICES, JSON.stringify(list));
    }

    function getActive(){
      try{ return JSON.parse(localStorage.getItem(LS_ACTIVE) || "null"); }
      catch{ return null; }
    }
    function setActive(deviceObj){
      localStorage.setItem(LS_ACTIVE, JSON.stringify(deviceObj));
    }
    function clearActive(){
      localStorage.removeItem(LS_ACTIVE);
    }

    function upsertDevice(dev){
      const list = loadDevices();
      const i = list.findIndex(x => x.id === dev.id);
      if(i >= 0) list[i] = { ...list[i], ...dev, savedAt: list[i].savedAt || Date.now() };
      else list.unshift({ ...dev, savedAt: Date.now() });
      saveDevices(list);
      renderSaved();
    }

    function removeDevice(id){
      const list = loadDevices().filter(x => x.id !== id);
      saveDevices(list);

      const active = getActive();
      if(active && active.id === id) clearActive();

      if(selectedSavedId === id) selectedSavedId = null;
      renderSaved();
      syncContinueState();
    }

    function syncContinueState(){
      
      continueBtn.disabled = !(selectedSavedId || selectedScanId);
    }

    
    function renderScan(){
      scanList.innerHTML = "";

      const arr = Array.from(seen.values())
        .sort((a,b) => (b.rssi ?? -999) - (a.rssi ?? -999));

      if(arr.length === 0){
        scanList.innerHTML = `
          <div class="item" style="opacity:.75">
            <div class="left">
              <span class="dot" style="background:#94a3b8; box-shadow:none"></span>
              <span class="name">Aún no hay resultados</span>
            </div>
            <span class="meta">—</span>
          </div>
        `;
        return;
      }

      arr.forEach(d => {
        const row = document.createElement("div");
        row.className = "item";
        row.style.outline = (selectedScanId === d.id) ? "2px solid rgba(255,255,255,.25)" : "none";

        row.innerHTML = `
          <div class="left">
            <span class="dot"></span>
            <span class="name" title="${esc(d.name)}">${esc(d.name)}</span>
          </div>

          <div class="btns">
            <div class="meta">${(d.rssi != null) ? `${d.rssi} dBm` : "BLE"}</div>
            <button class="smallBtn" data-action="add" title="Guardar">
              <ion-icon name="add-circle-outline"></ion-icon> Añadir
            </button>
          </div>
        `;

        row.addEventListener("click", (e) => {
          const btn = e.target.closest("button[data-action]");
          if(btn) return; 

          selectedScanId = d.id;
          selectedSavedId = null;
          renderScan();
          renderSaved();
          syncContinueState();
        });

        row.querySelector('button[data-action="add"]').addEventListener("click", () => {
          upsertDevice({ id: d.id, name: d.name || "Dispositivo BLE", idShort: d.id.slice(0,8) });
          setStatus(`Guardado: ${d.name}`);
        });

        scanList.appendChild(row);
      });
    }

    function renderSaved(){
      const list = loadDevices();
      const active = getActive();

      savedList.innerHTML = "";

      if(list.length === 0){
        savedList.innerHTML = `
          <div class="item" style="opacity:.75">
            <div class="left">
              <span class="dot" style="background:#94a3b8; box-shadow:none"></span>
              <span class="name">No hay dispositivos guardados</span>
            </div>
            <span class="meta">—</span>
          </div>
        `;
        return;
      }

      list.forEach(d => {
        const isActive = active && active.id === d.id;

        const row = document.createElement("div");
        row.className = "item";
        row.style.outline = (selectedSavedId === d.id) ? "2px solid rgba(255,255,255,.25)" : "none";

        row.innerHTML = `
          <div class="left">
            <span class="dot" style="${isActive ? "" : "background:#a3e635;"}"></span>
            <span class="name" title="${esc(d.name)}">${esc(d.name)}</span>
          </div>

          <div class="btns">
            <div class="meta">
              <div style="font-weight:700;color:#fff;opacity:.9">${esc(d.idShort || d.id?.slice(0,8) || "BLE")}</div>
              <div style="opacity:.85">${isActive ? "Activo" : "Guardado"}</div>
            </div>

            <button class="smallBtn" data-action="del" title="Eliminar">
              <ion-icon name="trash-outline"></ion-icon>
            </button>
          </div>
        `;

        row.addEventListener("click", (e) => {
          const delBtn = e.target.closest('button[data-action="del"]');
          if(delBtn) return;

          selectedSavedId = d.id;
          selectedScanId = null;
          renderSaved();
          renderScan();
          syncContinueState();
        });

        row.querySelector('button[data-action="del"]').addEventListener("click", () => {
          removeDevice(d.id);
          setStatus("Dispositivo eliminado.");
        });

        savedList.appendChild(row);
      });
    }

    // =========Logica conexion xcon la pulsera mediante ble =========

    function bleAvailable(){
      return !!navigator.bluetooth;
    }

    async function startScanInlineIfPossible(){
      
      if(!navigator.bluetooth?.requestLEScan){
        return false;
      }

      try{
        setStatus("Escaneando BLE… (aparecerán en la lista)");
        stopBtn.style.display = "grid";

        leScan = await navigator.bluetooth.requestLEScan({
          acceptAllAdvertisements: true
          
        });

        navigator.bluetooth.addEventListener("advertisementreceived", onAdv);
        return true;
      }catch(e){
        
        stopScan();
        setStatus("No se pudo iniciar escaneo en lista. Usando selector del sistema.");
        return false;
      }
    }

    function onAdv(event){
      const id = event.device?.id || crypto.randomUUID();
      const name = event.device?.name || event.name || "Dispositivo BLE";

      const rssi = (typeof event.rssi === "number") ? event.rssi : null;

      seen.set(id, { id, name, rssi, lastSeen: Date.now() });
      renderScan();
    }

    function stopScan(){
      try{
        if(leScan) leScan.stop();
      }catch{}
      leScan = null;

      try{
        navigator.bluetooth.removeEventListener("advertisementreceived", onAdv);
      }catch{}

      stopBtn.style.display = "none";
    }

    async function fallbackPickDeviceSystem(){
      try{
        setStatus("Abriendo selector de dispositivos…");
        const device = await navigator.bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: ["heart_rate"]
        });

        
        const id = device.id || crypto.randomUUID();
        const name = device.name || "Dispositivo BLE";

        upsertDevice({ id, name, idShort: id.slice(0,8) });

        selectedSavedId = id;
        selectedScanId = null;

        setStatus(`Añadido: ${name}`);
        renderSaved();
        syncContinueState();
      }catch(e){
        setStatus("Cancelado o no se pudo abrir el selector BLE.");
      }
    }

    
    scanBtn.addEventListener("click", async () => {
      if(!bleAvailable()){
        setStatus("Web Bluetooth no disponible en este navegador.");
        return;
      }

      
      const ok = await startScanInlineIfPossible();
      if(!ok){
        await fallbackPickDeviceSystem();
      }
    });

    stopBtn.addEventListener("click", () => {
      stopScan();
      setStatus("Escaneo detenido.");
    });

    disconnectBtn.addEventListener("click", () => {
      clearActive();
      selectedSavedId = null;
      selectedScanId = null;
      setStatus("Desconectado (dispositivo activo eliminado).");
      renderSaved();
      renderScan();
      syncContinueState();
    });

    continueBtn.addEventListener("click", () => {
    
      if(selectedSavedId){
        const d = loadDevices().find(x => x.id === selectedSavedId);
        if(d){
          setActive(d);
          window.location.href = "index.html";
        }
        return;
      }

      if(selectedScanId){
        const d = seen.get(selectedScanId);
        if(d){
          upsertDevice({ id: d.id, name: d.name, idShort: d.id.slice(0,8) });
          setActive({ id: d.id, name: d.name, idShort: d.id.slice(0,8) });
          window.location.href = "index.html";
        }
      }
    });

   
    renderScan();
    renderSaved();
    syncContinueState();